-- =====================================================================
-- Khazna · Phase 1 foundation
-- Zero-knowledge model: the server never sees document contents. It stores
-- AES-GCM ciphertext (`sealed`) plus the minimum needed to sync.
-- Grants are explicit so the result does not depend on project defaults.
-- =====================================================================

-- ---------- helpers --------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end
$$;

-- ---------- profiles -------------------------------------------------
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  locale       text not null default 'ar' check (locale in ('ar', 'en')),
  country_code text check (country_code ~ '^[A-Z]{2}$'),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create trigger profiles_touch
  before update on public.profiles
  for each row execute function public.touch_updated_at();

-- ---------- entitlements (written only by the service role) ----------
create table public.entitlements (
  user_id            uuid primary key references auth.users (id) on delete cascade,
  tier               text not null default 'trial' check (tier in ('free', 'trial', 'pro')),
  trial_ends_at      timestamptz,
  promo_ends_at      timestamptz,          -- end of the 2-month hook price
  store              text check (store in ('apple', 'google')),
  current_period_end timestamptz,
  updated_at         timestamptz not null default now()
);

create trigger entitlements_touch
  before update on public.entitlements
  for each row execute function public.touch_updated_at();

-- ---------- encrypted sync mirror (documents + bills) ----------------
create table public.sync_items (
  owner_id   uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id         uuid not null,                -- same uuid as the local Isar record
  kind       text not null check (kind in ('document', 'bill')),
  sealed     bytea not null check (octet_length(sealed) between 30 and 1048576),
  version    integer not null default 1 check (version >= 1),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  -- (owner_id, id): another user cannot probe or squat an id.
  primary key (owner_id, id)
);

create index sync_items_owner_updated_idx on public.sync_items (owner_id, updated_at);

-- Server-owned timestamps, immutable identity, optimistic concurrency.
create or replace function public.sync_items_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if (new.owner_id, new.id, new.kind) is distinct from (old.owner_id, old.id, old.kind) then
    raise exception 'sync_items: owner_id, id and kind are immutable';
  end if;

  if new.version <> old.version + 1 then
    raise exception 'version_conflict'
      using errcode = 'P0409', detail = format('server version is %s', old.version);
  end if;

  new.created_at := old.created_at;
  new.updated_at := now();
  return new;
end
$$;

create trigger sync_items_guard
  before insert or update on public.sync_items
  for each row execute function public.sync_items_guard();

-- ---------- new-user bootstrap ---------------------------------------
-- Trial length mirrors the product spec (30 days, no card).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  insert into public.entitlements (user_id, tier, trial_ends_at)
    values (new.id, 'trial', now() + interval '30 days')
    on conflict do nothing;
  return new;
end
$$;

revoke execute on function public.handle_new_user() from public, anon, authenticated;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- effective tier (display only; gate paid APIs server-side) --
create or replace function public.my_tier()
returns text
language sql
stable
set search_path = ''
as $$
  select coalesce((
    select case
      when e.tier = 'pro'   and e.current_period_end > now() then 'pro'
      when e.tier = 'trial' and e.trial_ends_at      > now() then 'trial'
      else 'free'
    end
    from public.entitlements e
    where e.user_id = (select auth.uid())
  ), 'free');
$$;

revoke execute on function public.my_tier() from public, anon;
grant  execute on function public.my_tier() to authenticated;

-- ---------- grants ---------------------------------------------------
revoke all on public.profiles     from anon, authenticated;
revoke all on public.entitlements from anon, authenticated;
revoke all on public.sync_items   from anon, authenticated;

grant select                         on public.profiles     to authenticated;
grant update (locale, country_code)  on public.profiles     to authenticated;
grant select                         on public.entitlements to authenticated;
grant select, insert, update, delete on public.sync_items   to authenticated;

-- ---------- row level security ---------------------------------------
alter table public.profiles     enable row level security;
alter table public.entitlements enable row level security;
alter table public.sync_items   enable row level security;

create policy profiles_select_own on public.profiles
  for select to authenticated
  using (id = (select auth.uid()));

create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- No write policies on entitlements: only the service role (Vercel webhook) writes.
create policy entitlements_select_own on public.entitlements
  for select to authenticated
  using (user_id = (select auth.uid()));

create policy sync_items_select_own on public.sync_items
  for select to authenticated
  using (owner_id = (select auth.uid()));

create policy sync_items_insert_own on public.sync_items
  for insert to authenticated
  with check (owner_id = (select auth.uid()));

create policy sync_items_update_own on public.sync_items
  for update to authenticated
  using (owner_id = (select auth.uid()))
  with check (owner_id = (select auth.uid()));

create policy sync_items_delete_own on public.sync_items
  for delete to authenticated
  using (owner_id = (select auth.uid()));

-- ---------- storage: private bucket of encrypted blobs ---------------
-- Object path convention: <user uuid>/<item uuid>/<blob uuid>.bin
-- Clients must upload with contentType application/octet-stream.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('vault-blobs', 'vault-blobs', false, 15728640, array['application/octet-stream'])
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

create policy vault_blobs_select_own on storage.objects
  for select to authenticated
  using (bucket_id = 'vault-blobs' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy vault_blobs_insert_own on storage.objects
  for insert to authenticated
  with check (bucket_id = 'vault-blobs' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy vault_blobs_update_own on storage.objects
  for update to authenticated
  using (bucket_id = 'vault-blobs' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'vault-blobs' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy vault_blobs_delete_own on storage.objects
  for delete to authenticated
  using (bucket_id = 'vault-blobs' and (storage.foldername(name))[1] = (select auth.uid())::text);
