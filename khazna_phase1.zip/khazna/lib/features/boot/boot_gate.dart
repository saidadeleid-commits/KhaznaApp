import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/crypto/key_vault.dart';
import '../../core/theme/khazna_tokens.dart';
import '../../core/widgets/khazna_plate.dart';
import '../../providers.dart';

/// Entry point. Resolves the vault state; the unlock/setup experience
/// (dial animation, haptics) replaces the body in Phase 1b.
class BootGate extends ConsumerWidget {
  const BootGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.khazna;
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final brand = isArabic ? 'خزنة' : 'Khazna';

    return Scaffold(
      body: Center(
        child: ref.watch(vaultStatusProvider).when(
              loading: () => CircularProgressIndicator(color: t.brassInk),
              error: (e, _) => Padding(
                padding: const EdgeInsets.all(24),
                child: Text('$e', textAlign: TextAlign.center),
              ),
              data: (status) => KhaznaPlate(
                semanticLabel: brand,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      status == VaultStatus.unlocked ? Icons.lock_open_rounded : Icons.lock_rounded,
                      size: 40,
                      color: t.brassInk,
                    ),
                    const SizedBox(height: 12),
                    Text(brand, style: Theme.of(context).textTheme.displaySmall),
                  ],
                ),
              ),
            ),
      ),
    );
  }
}
