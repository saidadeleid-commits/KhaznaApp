import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/prefs/ui_prefs.dart';
import 'core/theme/khazna_theme.dart';
import 'features/boot/boot_gate.dart';

class KhaznaApp extends ConsumerWidget {
  const KhaznaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final prefs = ref.watch(uiPrefsProvider);
    return MaterialApp(
      title: 'Khazna',
      debugShowCheckedModeBanner: false,
      theme: KhaznaTheme.light(),
      darkTheme: KhaznaTheme.dark(),
      themeMode: prefs.themeMode,
      // The locale decides text direction: ar = RTL, en = LTR.
      locale: prefs.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const BootGate(),
    );
  }
}
