import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:isar_community/isar.dart';

import 'core/crypto/field_cipher.dart';
import 'core/crypto/key_vault.dart';
import 'data/local/isar_service.dart';
import 'data/repositories/document_repository.dart';

final keyVaultProvider = Provider<KeyVault>((ref) => KeyVault());

class VaultStatusNotifier extends AsyncNotifier<VaultStatus> {
  KeyVault get _vault => ref.read(keyVaultProvider);

  @override
  Future<VaultStatus> build() => _vault.status();

  Future<void> setUp(String passphrase) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      await _vault.initialize(passphrase);
      return _vault.status();
    });
  }

  /// Returns false when the passphrase is wrong.
  Future<bool> unlock(String passphrase) async {
    try {
      await _vault.unlock(passphrase);
      state = AsyncData(await _vault.status());
      return true;
    } on WrongPassphraseException {
      return false;
    }
  }

  Future<void> lock() async {
    _vault.lock();
    state = AsyncData(await _vault.status());
  }
}

final vaultStatusProvider =
    AsyncNotifierProvider<VaultStatusNotifier, VaultStatus>(VaultStatusNotifier.new);

/// Throws while the vault is locked, so nothing can read records without the key.
final fieldCipherProvider = Provider<FieldCipher>((ref) {
  final status = ref.watch(vaultStatusProvider);
  if (status case AsyncData(value: VaultStatus.unlocked)) {
    return FieldCipher(ref.read(keyVaultProvider).fieldKey);
  }
  throw StateError('Vault is locked');
});

final isarProvider = FutureProvider<Isar>((ref) async {
  final isar = await IsarService.open();
  ref.onDispose(isar.close);
  return isar;
});

final documentRepositoryProvider = FutureProvider<DocumentRepository>((ref) async {
  final isar = await ref.watch(isarProvider.future);
  return DocumentRepository(isar, ref.watch(fieldCipherProvider));
});

final vaultEntriesProvider = StreamProvider<List<VaultEntry>>((ref) async* {
  final repo = await ref.watch(documentRepositoryProvider.future);
  yield* repo.watchAll();
});
