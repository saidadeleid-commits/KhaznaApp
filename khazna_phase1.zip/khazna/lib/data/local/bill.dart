import 'package:isar_community/isar.dart';

import 'sync_state.dart';

part 'bill.g.dart';

enum BillStatus { upcoming, paid, snoozed }

enum Recurrence { none, monthly, quarterly, yearly }

/// Title, amount, currency and notes live in [sealed]. Repository comes in Phase 3.
@collection
class Bill {
  Id id = Isar.autoIncrement;

  @Index(unique: true, replace: true)
  late String uuid;

  /// Calendar date stored as UTC midnight.
  @Index()
  late DateTime dueOn;

  @Enumerated(EnumType.name)
  BillStatus status = BillStatus.upcoming;

  @Enumerated(EnumType.name)
  Recurrence recurrence = Recurrence.none;

  DateTime? snoozedUntil;

  late List<byte> sealed;

  @Enumerated(EnumType.name)
  SyncState syncState = SyncState.pending;

  int version = 1;
  bool isDeleted = false;
  late DateTime createdAt;
  late DateTime updatedAt;
}
