import 'package:isar_community/isar.dart';

import 'sync_state.dart';

part 'vault_document.g.dart';

enum DocumentCategory {
  nationalId,
  passport,
  drivingLicense,
  vehicleLicense,
  insurance,
  warranty,
  propertyContract,
  medical,
  custom,
}

/// Plain columns are only what must work while locked (reminders, ordering).
/// Everything identifying (title, numbers, notes, file paths) is in [sealed].
@collection
class VaultDocument {
  Id id = Isar.autoIncrement;

  @Index(unique: true, replace: true)
  late String uuid;

  @Enumerated(EnumType.name)
  late DocumentCategory category;

  /// Calendar date stored as UTC midnight (see `daysUntil`).
  @Index()
  DateTime? expiresOn;

  int remindDaysBefore = 30;

  /// AES-GCM-256 envelope: nonce | ciphertext | tag.
  late List<byte> sealed;

  @Enumerated(EnumType.name)
  SyncState syncState = SyncState.pending;

  int version = 1;
  bool isDeleted = false;
  late DateTime createdAt;
  late DateTime updatedAt;
}
