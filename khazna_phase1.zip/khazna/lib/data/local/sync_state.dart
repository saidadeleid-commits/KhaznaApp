enum SyncState { pending, synced, conflict }
