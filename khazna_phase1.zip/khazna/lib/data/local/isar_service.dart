import 'package:isar_community/isar.dart';
import 'package:path_provider/path_provider.dart';

import 'bill.dart';
import 'vault_document.dart';

/// Isar does not encrypt its files, so confidentiality comes from sealing the
/// sensitive fields (see FieldCipher) before they reach the database.
abstract final class IsarService {
  static const name = 'khazna';

  static Future<Isar> open() async {
    final existing = Isar.getInstance(name);
    if (existing != null) return existing;
    final dir = await getApplicationSupportDirectory();
    return Isar.open(
      [VaultDocumentSchema, BillSchema],
      directory: dir.path,
      name: name,
      inspector: false,
    );
  }
}
