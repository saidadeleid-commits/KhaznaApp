import 'package:supabase_flutter/supabase_flutter.dart';

/// Credentials come from `--dart-define-from-file=env.json`. Only the anon or
/// publishable key belongs in the app; never the service-role key.
abstract final class SupabaseConfig {
  static const url = String.fromEnvironment('SUPABASE_URL');
  static const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  /// Without credentials the app still runs, fully local (offline-first).
  static bool get isConfigured => url.isNotEmpty && anonKey.isNotEmpty;

  static Future<void> initialize() async {
    await Supabase.initialize(
      url: url,
      anonKey: anonKey,
      authOptions: const FlutterAuthClientOptions(authFlowType: AuthFlowType.pkce),
    );
  }

  static SupabaseClient? get client => isConfigured ? Supabase.instance.client : null;
}
