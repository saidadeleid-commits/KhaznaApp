import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:isar_community/isar.dart';
import 'package:uuid/uuid.dart';

import '../../core/crypto/field_cipher.dart';
import '../../core/domain/expiry.dart';
import '../local/sync_state.dart';
import '../local/vault_document.dart';

/// Decrypted content of a document. `category`, `expiresOn` and
/// `remindDaysBefore` are duplicated inside the sealed JSON so a restore from
/// the server (ciphertext only) can rebuild the plain index columns.
class DocumentPayload {
  const DocumentPayload({
    required this.category,
    required this.title,
    this.holderName,
    this.number,
    this.notes,
    this.attachments = const [],
    this.expiresOn,
    this.remindDaysBefore = 30,
  });

  final DocumentCategory category;
  final String title;
  final String? holderName;
  final String? number;
  final String? notes;

  /// Paths of encrypted blobs in the `vault-blobs` bucket.
  final List<String> attachments;

  /// Calendar date as UTC midnight.
  final DateTime? expiresOn;
  final int remindDaysBefore;

  Map<String, dynamic> toJson() => {
        'category': category.name,
        'title': title,
        if (holderName != null) 'holderName': holderName,
        if (number != null) 'number': number,
        if (notes != null) 'notes': notes,
        'attachments': attachments,
        if (expiresOn != null) 'expiresOn': expiresOn!.toIso8601String().substring(0, 10),
        'remindDaysBefore': remindDaysBefore,
      };

  factory DocumentPayload.fromJson(Map<String, dynamic> j) => DocumentPayload(
        category: DocumentCategory.values.byName(j['category'] as String),
        title: j['title'] as String,
        holderName: j['holderName'] as String?,
        number: j['number'] as String?,
        notes: j['notes'] as String?,
        attachments: ((j['attachments'] as List?) ?? const []).cast<String>(),
        expiresOn: j['expiresOn'] == null ? null : DateTime.parse('${j['expiresOn']}T00:00:00Z'),
        remindDaysBefore: (j['remindDaysBefore'] as int?) ?? 30,
      );
}

class VaultEntry {
  const VaultEntry(this.meta, this.data);

  final VaultDocument meta;
  final DocumentPayload data;

  int? get daysLeft => meta.expiresOn == null ? null : daysUntil(meta.expiresOn!);

  ExpiryStatus? get status {
    final d = daysLeft;
    return d == null ? null : expiryStatusFor(d, dueSoonDays: meta.remindDaysBefore);
  }
}

class DocumentRepository {
  DocumentRepository(this._isar, this._cipher);

  final Isar _isar;
  final FieldCipher _cipher;

  static final _far = DateTime.utc(9999);

  static String _aad(String uuid) => 'vault_document:$uuid';

  /// Creates a document, or updates it when [uuid] already exists.
  Future<VaultEntry> save(DocumentPayload data, {String? uuid}) async {
    final id = uuid ?? const Uuid().v4();
    final now = DateTime.now().toUtc();
    final sealed = await _cipher.seal(data.toJson(), aad: _aad(id));

    return _isar.writeTxn(() async {
      final existing = await _isar.vaultDocuments.getByUuid(id);
      final doc = existing ?? (VaultDocument()..uuid = id..createdAt = now);
      doc
        ..category = data.category
        ..expiresOn = data.expiresOn
        ..remindDaysBefore = data.remindDaysBefore
        ..sealed = sealed
        ..syncState = SyncState.pending
        ..version = existing == null ? 1 : existing.version + 1
        ..isDeleted = false
        ..updatedAt = now;
      await _isar.vaultDocuments.put(doc);
      return VaultEntry(doc, data);
    });
  }

  Future<void> softDelete(String uuid) => _isar.writeTxn(() async {
        final doc = await _isar.vaultDocuments.getByUuid(uuid);
        if (doc == null) return;
        doc
          ..isDeleted = true
          ..syncState = SyncState.pending
          ..version += 1
          ..updatedAt = DateTime.now().toUtc();
        await _isar.vaultDocuments.put(doc);
      });

  /// Live list, soonest expiry first, undated documents last.
  Stream<List<VaultEntry>> watchAll() => _isar.vaultDocuments
      .filter()
      .isDeletedEqualTo(false)
      .watch(fireImmediately: true)
      .asyncMap(_open);

  Future<List<VaultEntry>> _open(List<VaultDocument> docs) async {
    final out = <VaultEntry>[];
    for (final d in docs) {
      try {
        final json = await _cipher.open(d.sealed, aad: _aad(d.uuid));
        out.add(VaultEntry(d, DocumentPayload.fromJson(json)));
      } on SecretBoxAuthenticationError {
        // One unreadable record must not hide the rest.
        debugPrint('Khazna: skipped undecryptable document ${d.uuid}');
      }
    }
    out.sort((a, b) => (a.meta.expiresOn ?? _far).compareTo(b.meta.expiresOn ?? _far));
    return out;
  }
}
