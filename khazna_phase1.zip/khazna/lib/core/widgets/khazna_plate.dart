import 'package:flutter/material.dart';

import '../theme/khazna_tokens.dart';

enum PlateTone { surface, brass }

/// The 3D primitive of the design system: a plate with a rim-lit bevel, a
/// vertical fill gradient and a two-layer shadow. Cards, passes and bills are
/// all built on it. On [PlateTone.brass] use `KhaznaPalette.obsidianLapis` for
/// content colour.
class KhaznaPlate extends StatelessWidget {
  const KhaznaPlate({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.radius = 24,
    this.tone = PlateTone.surface,
    this.onTap,
    this.semanticLabel,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final PlateTone tone;
  final VoidCallback? onTap;
  final String? semanticLabel;

  static const _rim = 1.2;

  @override
  Widget build(BuildContext context) {
    final t = context.khazna;
    final inner = BorderRadius.circular(radius - _rim);
    final fill = switch (tone) {
      PlateTone.surface => LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [t.plateLift, t.plate],
        ),
      PlateTone.brass => t.brass,
    };
    final padded = Padding(padding: padding, child: child);

    return Semantics(
      container: true,
      label: semanticLabel,
      button: onTap != null,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          gradient: t.bevel,
          boxShadow: t.plateShadows,
        ),
        child: Padding(
          padding: const EdgeInsets.all(_rim),
          child: Material(
            color: Colors.transparent,
            borderRadius: inner,
            clipBehavior: Clip.antiAlias,
            child: Ink(
              decoration: BoxDecoration(gradient: fill),
              child: onTap == null ? padded : InkWell(onTap: onTap, child: padded),
            ),
          ),
        ),
      ),
    );
  }
}
