import 'dart:convert';
import 'dart:isolate';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

enum VaultStatus { uninitialized, locked, unlocked }

class WrongPassphraseException implements Exception {
  const WrongPassphraseException();
  @override
  String toString() => 'Wrong passphrase';
}

/// Key hierarchy:
///   passphrase --PBKDF2-HMAC-SHA256(salt, iterations)--> KEK
///   KEK --AES-GCM--> wraps a random 256-bit master key (kept in Keychain/Keystore)
///   master --HKDF--> separate sub-keys for record fields and file blobs
///
/// Only the wrapped master key, salt and iteration count are persisted. The
/// passphrase and master key never touch disk; sub-keys live in memory until [lock].
class KeyVault {
  KeyVault({FlutterSecureStorage? storage, this.iterations = 600000})
      : _store = storage ??
            const FlutterSecureStorage(
              iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
            );

  static const _kWrapped = 'khazna.mk.wrapped.v1';
  static const _kSalt = 'khazna.mk.salt.v1';
  static const _kIters = 'khazna.mk.iters.v1';

  static final _aes = AesGcm.with256bits();
  static final _wrapAad = utf8.encode('khazna/v1/master-key');

  final FlutterSecureStorage _store;

  /// OWASP's 2023 floor for PBKDF2-HMAC-SHA256. Benchmark on low-end phones.
  final int iterations;

  SecretKey? _fieldKey;
  SecretKey? _blobKey;

  bool get isUnlocked => _fieldKey != null;

  SecretKey get fieldKey => _fieldKey ?? (throw StateError('Vault is locked'));
  SecretKey get blobKey => _blobKey ?? (throw StateError('Vault is locked'));

  Future<VaultStatus> status() async {
    if (isUnlocked) return VaultStatus.unlocked;
    return await _store.containsKey(key: _kWrapped) ? VaultStatus.locked : VaultStatus.uninitialized;
  }

  /// First run: creates the master key, wraps it with [passphrase] and unlocks.
  Future<void> initialize(String passphrase) async {
    if (await _store.containsKey(key: _kWrapped)) {
      throw StateError('Vault is already initialised');
    }
    final master = _randomBytes(32);
    final salt = _randomBytes(16);
    final kek = await _derive(passphrase, salt, iterations);
    final box = await _aes.encrypt(master, secretKey: SecretKey(kek), aad: _wrapAad);

    await _store.write(key: _kSalt, value: base64Encode(salt));
    await _store.write(key: _kIters, value: '$iterations');
    // Written last: a crash earlier leaves the vault "uninitialised", never half-set-up.
    await _store.write(key: _kWrapped, value: base64Encode(box.concatenation()));
    await _install(master);
  }

  /// Throws [WrongPassphraseException] if [passphrase] does not open the vault.
  Future<void> unlock(String passphrase) async {
    final wrapped = await _store.read(key: _kWrapped);
    final salt = await _store.read(key: _kSalt);
    final iters = await _store.read(key: _kIters);
    if (wrapped == null || salt == null || iters == null) {
      throw StateError('Vault is not initialised');
    }
    final kek = await _derive(passphrase, base64Decode(salt), int.parse(iters));
    try {
      final master = await _aes.decrypt(
        SecretBox.fromConcatenation(
          base64Decode(wrapped),
          nonceLength: AesGcm.defaultNonceLength,
          macLength: 16,
        ),
        secretKey: SecretKey(kek),
        aad: _wrapAad,
      );
      await _install(master);
    } on SecretBoxAuthenticationError {
      throw const WrongPassphraseException();
    }
  }

  void lock() {
    _fieldKey = null;
    _blobKey = null;
  }

  Future<void> _install(List<int> master) async {
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    final root = SecretKey(master);
    _fieldKey = await hkdf.deriveKey(secretKey: root, info: utf8.encode('khazna/v1/fields'));
    _blobKey = await hkdf.deriveKey(secretKey: root, info: utf8.encode('khazna/v1/blobs'));
  }

  /// PBKDF2 runs in a background isolate so the unlock animation stays smooth.
  static Future<List<int>> _derive(String passphrase, List<int> salt, int iterations) {
    return Isolate.run(() async {
      final key = await Pbkdf2(
        macAlgorithm: Hmac.sha256(),
        iterations: iterations,
        bits: 256,
      ).deriveKeyFromPassword(password: passphrase, nonce: salt);
      return key.extractBytes();
    });
  }

  static Uint8List _randomBytes(int length) {
    final rng = Random.secure();
    return Uint8List.fromList(List<int>.generate(length, (_) => rng.nextInt(256)));
  }
}
