import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

/// AES-GCM-256 envelope for record payloads. Output layout: nonce | ciphertext | tag.
///
/// Each record passes an [aad] string (e.g. `vault_document:<uuid>`). It is
/// authenticated but not stored, so a ciphertext copied onto another record
/// fails to open instead of silently showing the wrong data.
class FieldCipher {
  FieldCipher(this._key);

  final SecretKey _key;

  static final _aes = AesGcm.with256bits();
  static const _macLength = 16;

  Future<Uint8List> seal(Map<String, dynamic> json, {required String aad}) async {
    final box = await _aes.encrypt(
      utf8.encode(jsonEncode(json)),
      secretKey: _key,
      aad: utf8.encode(aad),
    );
    return Uint8List.fromList(box.concatenation());
  }

  /// Throws [SecretBoxAuthenticationError] on a wrong key, tampering or wrong [aad].
  Future<Map<String, dynamic>> open(List<int> sealed, {required String aad}) async {
    final box = SecretBox.fromConcatenation(
      sealed,
      nonceLength: AesGcm.defaultNonceLength,
      macLength: _macLength,
    );
    final clear = await _aes.decrypt(box, secretKey: _key, aad: utf8.encode(aad));
    return jsonDecode(utf8.decode(clear)) as Map<String, dynamic>;
  }
}
