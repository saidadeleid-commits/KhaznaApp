import 'package:flutter/material.dart';

import 'khazna_tokens.dart';
import 'khazna_type.dart';

abstract final class KhaznaTheme {
  static ThemeData dark() => _build(KhaznaTokens.dark, Brightness.dark);
  static ThemeData light() => _build(KhaznaTokens.light, Brightness.light);

  static ThemeData _build(KhaznaTokens t, Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    final scheme = ColorScheme(
      brightness: brightness,
      primary: isDark ? KhaznaPalette.brassHighlight : KhaznaPalette.brassShadow,
      onPrimary: KhaznaPalette.obsidianLapis,
      secondary: KhaznaPalette.brassShadow,
      onSecondary: KhaznaPalette.obsidianLapis,
      error: t.overdue,
      onError: Colors.white,
      surface: t.plate,
      onSurface: t.textPrimary,
      outline: t.hairline,
    );
    final text = KhaznaType.textTheme(primary: t.textPrimary, muted: t.textMuted);

    OutlineInputBorder border(Color color, [double width = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: color, width: width),
        );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: t.base,
      canvasColor: t.base,
      fontFamily: KhaznaType.family,
      textTheme: text,
      dividerColor: t.hairline,
      extensions: [t],
      splashFactory: InkRipple.splashFactory,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: text.titleLarge,
        iconTheme: IconThemeData(color: t.textPrimary),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(56),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: text.titleMedium,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: t.plate,
        border: border(t.hairline),
        enabledBorder: border(t.hairline),
        focusedBorder: border(scheme.primary, 1.6),
        errorBorder: border(t.overdue),
        focusedErrorBorder: border(t.overdue, 1.6),
      ),
    );
  }
}
