import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

/// Cairo, bundled in assets/fonts (works offline).
///
/// Every style sets `letterSpacing: 0`. Any tracking, positive or negative,
/// breaks the cursive joining of Arabic letters.
abstract final class KhaznaType {
  static const family = 'Cairo';

  static TextStyle _s(double size, FontWeight weight, double height, Color color) => TextStyle(
        fontFamily: family,
        fontSize: size,
        fontWeight: weight,
        height: height,
        letterSpacing: 0,
        color: color,
      );

  static TextTheme textTheme({required Color primary, required Color muted}) => TextTheme(
        displayLarge: _s(48, FontWeight.w800, 1.15, primary),
        displayMedium: _s(40, FontWeight.w800, 1.2, primary),
        displaySmall: _s(32, FontWeight.w700, 1.25, primary),
        headlineLarge: _s(28, FontWeight.w700, 1.3, primary),
        headlineMedium: _s(24, FontWeight.w700, 1.35, primary),
        headlineSmall: _s(20, FontWeight.w700, 1.4, primary),
        titleLarge: _s(20, FontWeight.w600, 1.4, primary),
        titleMedium: _s(16, FontWeight.w600, 1.5, primary),
        titleSmall: _s(14, FontWeight.w600, 1.5, primary),
        bodyLarge: _s(16, FontWeight.w400, 1.65, primary),
        bodyMedium: _s(14, FontWeight.w400, 1.65, primary),
        bodySmall: _s(12, FontWeight.w400, 1.6, muted),
        labelLarge: _s(14, FontWeight.w600, 1.4, primary),
        labelMedium: _s(12, FontWeight.w600, 1.4, muted),
        labelSmall: _s(11, FontWeight.w500, 1.4, muted),
      );

  /// Giant countdown numerals ("14" days left). Digits only: the negative
  /// tracking is safe for numerals but must never be used on Arabic words.
  static TextStyle countdown(Color color) => TextStyle(
        fontFamily: family,
        fontSize: 112,
        fontWeight: FontWeight.w800,
        height: 0.95,
        letterSpacing: -2,
        fontFeatures: const [FontFeature.tabularFigures()],
        color: color,
      );
}
