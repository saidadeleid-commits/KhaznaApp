import 'package:flutter/material.dart';

import '../domain/expiry.dart';

/// Brand constants from the spec. In widgets prefer [KhaznaTokens].
abstract final class KhaznaPalette {
  static const obsidianLapis = Color(0xFF0B1220);
  static const ceramicPaper = Color(0xFFF4F5F8);
  static const brassHighlight = Color(0xFFE6B84C);
  static const brassShadow = Color(0xFFB3831E);
  static const emerald = Color(0xFF10B981);
  static const amber = Color(0xFFF59E0B);
  static const ruby = Color(0xFFEF4444);
}

const _brassGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [KhaznaPalette.brassHighlight, KhaznaPalette.brassShadow],
);

/// Semantic design tokens. Read with `context.khazna`.
@immutable
class KhaznaTokens extends ThemeExtension<KhaznaTokens> {
  const KhaznaTokens({
    required this.base,
    required this.plate,
    required this.plateLift,
    required this.hairline,
    required this.textPrimary,
    required this.textMuted,
    required this.brassInk,
    required this.valid,
    required this.dueSoon,
    required this.overdue,
    required this.brass,
    required this.bevel,
    required this.plateShadows,
  });

  final Color base;
  final Color plate;
  final Color plateLift;
  final Color hairline;
  final Color textPrimary;
  final Color textMuted;

  /// Brass that stays readable as small text on this theme's surfaces.
  final Color brassInk;
  final Color valid;
  final Color dueSoon;
  final Color overdue;
  final LinearGradient brass;

  /// 1px rim light: bright top edge, dark bottom edge. Gives plates thickness.
  final LinearGradient bevel;
  final List<BoxShadow> plateShadows;

  static const dark = KhaznaTokens(
    base: KhaznaPalette.obsidianLapis,
    plate: Color(0xFF111A2D),
    plateLift: Color(0xFF1A2640),
    hairline: Color(0xFF263552),
    textPrimary: KhaznaPalette.ceramicPaper,
    textMuted: Color(0xFF9AA6BF),
    brassInk: KhaznaPalette.brassHighlight,
    valid: KhaznaPalette.emerald,
    dueSoon: KhaznaPalette.amber,
    overdue: KhaznaPalette.ruby,
    brass: _brassGradient,
    bevel: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0x40FFFFFF), Color(0x0DFFFFFF), Color(0x80000000)],
    ),
    plateShadows: [
      BoxShadow(color: Color(0x99000000), blurRadius: 28, offset: Offset(0, 16)),
      BoxShadow(color: Color(0x4D000000), blurRadius: 4, offset: Offset(0, 2)),
    ],
  );

  /// Light mode uses deeper tones of the status hues so text passes 4.5:1.
  static const light = KhaznaTokens(
    base: KhaznaPalette.ceramicPaper,
    plate: Color(0xFFECEEF4),
    plateLift: Color(0xFFFFFFFF),
    hairline: Color(0xFFD9DCE6),
    textPrimary: KhaznaPalette.obsidianLapis,
    textMuted: Color(0xFF5B6578),
    brassInk: Color(0xFF7A560F),
    valid: Color(0xFF047857),
    dueSoon: Color(0xFFB45309),
    overdue: Color(0xFFB91C1C),
    brass: _brassGradient,
    bevel: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF), Color(0x330B1220)],
    ),
    plateShadows: [
      BoxShadow(color: Color(0x290B1220), blurRadius: 24, offset: Offset(0, 14)),
      BoxShadow(color: Color(0x140B1220), blurRadius: 3, offset: Offset(0, 1)),
    ],
  );

  Color statusColor(ExpiryStatus s) => switch (s) {
        ExpiryStatus.valid => valid,
        ExpiryStatus.dueSoon => dueSoon,
        ExpiryStatus.overdue => overdue,
      };

  @override
  KhaznaTokens copyWith({
    Color? base,
    Color? plate,
    Color? plateLift,
    Color? hairline,
    Color? textPrimary,
    Color? textMuted,
    Color? brassInk,
    Color? valid,
    Color? dueSoon,
    Color? overdue,
    LinearGradient? brass,
    LinearGradient? bevel,
    List<BoxShadow>? plateShadows,
  }) =>
      KhaznaTokens(
        base: base ?? this.base,
        plate: plate ?? this.plate,
        plateLift: plateLift ?? this.plateLift,
        hairline: hairline ?? this.hairline,
        textPrimary: textPrimary ?? this.textPrimary,
        textMuted: textMuted ?? this.textMuted,
        brassInk: brassInk ?? this.brassInk,
        valid: valid ?? this.valid,
        dueSoon: dueSoon ?? this.dueSoon,
        overdue: overdue ?? this.overdue,
        brass: brass ?? this.brass,
        bevel: bevel ?? this.bevel,
        plateShadows: plateShadows ?? this.plateShadows,
      );

  @override
  KhaznaTokens lerp(ThemeExtension<KhaznaTokens>? other, double t) {
    if (other is! KhaznaTokens) return this;
    Color c(Color a, Color b) => Color.lerp(a, b, t)!;
    return KhaznaTokens(
      base: c(base, other.base),
      plate: c(plate, other.plate),
      plateLift: c(plateLift, other.plateLift),
      hairline: c(hairline, other.hairline),
      textPrimary: c(textPrimary, other.textPrimary),
      textMuted: c(textMuted, other.textMuted),
      brassInk: c(brassInk, other.brassInk),
      valid: c(valid, other.valid),
      dueSoon: c(dueSoon, other.dueSoon),
      overdue: c(overdue, other.overdue),
      brass: t < 0.5 ? brass : other.brass,
      bevel: LinearGradient.lerp(bevel, other.bevel, t)!,
      plateShadows: BoxShadow.lerpList(plateShadows, other.plateShadows, t)!,
    );
  }
}

extension KhaznaThemeContext on BuildContext {
  KhaznaTokens get khazna => Theme.of(this).extension<KhaznaTokens>()!;
}
