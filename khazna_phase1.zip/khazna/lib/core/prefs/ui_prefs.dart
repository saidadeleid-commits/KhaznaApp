import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Overridden in main() once SharedPreferences has loaded.
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw StateError('sharedPrefsProvider must be overridden in main()'),
);

class UiPrefs {
  const UiPrefs({required this.locale, required this.themeMode});

  final Locale locale;
  final ThemeMode themeMode;

  UiPrefs copyWith({Locale? locale, ThemeMode? themeMode}) =>
      UiPrefs(locale: locale ?? this.locale, themeMode: themeMode ?? this.themeMode);
}

/// Arabic (RTL) is the default; toggling to English flips the layout to LTR.
class UiPrefsNotifier extends Notifier<UiPrefs> {
  static const _kLocale = 'ui.locale';
  static const _kTheme = 'ui.theme';

  @override
  UiPrefs build() {
    final p = ref.read(sharedPrefsProvider);
    return UiPrefs(
      locale: Locale(p.getString(_kLocale) == 'en' ? 'en' : 'ar'),
      themeMode: ThemeMode.values.asNameMap()[p.getString(_kTheme)] ?? ThemeMode.dark,
    );
  }

  Future<void> setLocale(Locale locale) async {
    state = state.copyWith(locale: locale);
    await ref.read(sharedPrefsProvider).setString(_kLocale, locale.languageCode);
  }

  Future<void> toggleLocale() =>
      setLocale(state.locale.languageCode == 'ar' ? const Locale('en') : const Locale('ar'));

  Future<void> setThemeMode(ThemeMode mode) async {
    state = state.copyWith(themeMode: mode);
    await ref.read(sharedPrefsProvider).setString(_kTheme, mode.name);
  }
}

final uiPrefsProvider = NotifierProvider<UiPrefsNotifier, UiPrefs>(UiPrefsNotifier.new);
