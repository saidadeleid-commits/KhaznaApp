enum ExpiryStatus { valid, dueSoon, overdue }

/// Whole calendar days from today until [date].
///
/// Expiry dates are calendar dates, stored as UTC midnight. Both sides are
/// reduced to a UTC y/m/d so a daylight-saving change (Egypt observes DST)
/// can never turn "tomorrow" into "today".
int daysUntil(DateTime date, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = DateTime.utc(n.year, n.month, n.day);
  final target = DateTime.utc(date.year, date.month, date.day);
  return target.difference(today).inDays;
}

ExpiryStatus expiryStatusFor(int daysLeft, {int dueSoonDays = 30}) {
  if (daysLeft < 0) return ExpiryStatus.overdue;
  if (daysLeft <= dueSoonDays) return ExpiryStatus.dueSoon;
  return ExpiryStatus.valid;
}
