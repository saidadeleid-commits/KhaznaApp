#!/usr/bin/env bash
# One-time bootstrap. Run from this folder:  bash setup.sh
# Needs: Flutter SDK on PATH. Cairo fonts must be in assets/fonts (see README note in the chat).
set -euo pipefail
cd "$(dirname "$0")"

# `flutter create` would drop its template app over ours, so park our sources first.
tmp="$(mktemp -d)"
mv lib supabase tool test "$tmp"/
flutter create --org com.khazna --project-name khazna --platforms=android,ios .
rm -rf lib test
mv "$tmp"/lib "$tmp"/supabase "$tmp"/tool "$tmp"/test .

# Latest compatible versions are resolved by pub itself (no stale pins).
flutter pub add flutter_riverpod supabase_flutter isar_community isar_community_flutter_libs \
  path_provider cryptography flutter_secure_storage shared_preferences uuid
flutter pub add flutter_localizations --sdk=flutter
flutter pub add --dev build_runner isar_community_generator

# Register the bundled Cairo font (offline-first: no runtime font downloads).
cat tool/pubspec_fonts.yaml >> pubspec.yaml
mkdir -p assets/fonts
for w in Regular Medium SemiBold Bold ExtraBold; do
  [ -f "assets/fonts/Cairo-$w.ttf" ] || echo "WARNING: assets/fonts/Cairo-$w.ttf is missing"
done

flutter pub get
dart run build_runner build --delete-conflicting-outputs
echo "Done. Run: flutter test && flutter run --dart-define-from-file=env.json"
