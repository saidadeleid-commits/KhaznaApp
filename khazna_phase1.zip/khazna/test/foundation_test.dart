import 'package:cryptography/cryptography.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:khazna/core/crypto/field_cipher.dart';
import 'package:khazna/core/domain/expiry.dart';

void main() {
  group('expiry', () {
    test('counts calendar days regardless of time of day', () {
      final expires = DateTime.utc(2027, 3, 15);
      expect(daysUntil(expires, now: DateTime(2027, 3, 14, 23, 59)), 1);
      expect(daysUntil(expires, now: DateTime(2027, 3, 15, 0, 1)), 0);
      expect(daysUntil(expires, now: DateTime(2027, 3, 16, 9)), -1);
    });

    test('status thresholds', () {
      expect(expiryStatusFor(-1), ExpiryStatus.overdue);
      expect(expiryStatusFor(0), ExpiryStatus.dueSoon);
      expect(expiryStatusFor(30), ExpiryStatus.dueSoon);
      expect(expiryStatusFor(31), ExpiryStatus.valid);
      expect(expiryStatusFor(45, dueSoonDays: 60), ExpiryStatus.dueSoon);
    });
  });

  group('FieldCipher', () {
    final cipher = FieldCipher(SecretKey(List<int>.filled(32, 7)));

    test('round-trips JSON', () async {
      final sealed = await cipher.seal({'title': 'جواز السفر', 'n': 1}, aad: 'doc:a');
      expect(await cipher.open(sealed, aad: 'doc:a'), {'title': 'جواز السفر', 'n': 1});
    });

    test('rejects a ciphertext moved to another record', () async {
      final sealed = await cipher.seal({'title': 'x'}, aad: 'doc:a');
      await expectLater(
        cipher.open(sealed, aad: 'doc:b'),
        throwsA(isA<SecretBoxAuthenticationError>()),
      );
    });
  });
}
